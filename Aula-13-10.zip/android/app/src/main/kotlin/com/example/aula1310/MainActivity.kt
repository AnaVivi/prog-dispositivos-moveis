package com.example.aula1310

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
